﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicineproject
{
    public class Class1
    {

        public string[] Search { get; set; }
        public string[] ValidData { get; set; }

        public string[] InvalidData { get; set; }
        public string[] SignV { get; set; }

        public string[] SignI { get; set; }


        public string[] Payment { get; set; }


        public string[] Data { get; set; }




    }
}
