﻿
using OpenQA.Selenium.Appium.Android;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobileapptesting
{
    public class BaseClass
    {
        public BaseClass()
        {
            
        }

       public static AndroidDriver<AndroidElement> driver;


    }
}