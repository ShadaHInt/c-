﻿
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Reflection;

using TechTalk.SpecFlow;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Configuration;
using Serilog.Core;
using Serilog;
using Serilog.Events;
using DocumentFormat.OpenXml.Drawing.ChartDrawing;
using System.Configuration;

namespace Myntraproject
{
    [Binding]

    public class Hooks : BaseClass
    {



        //Global Variable for Extend report

        private static ExtentTest? featureName;
        private static ExtentTest? scenario;
        private static ExtentReports? extent;
        public static string? logpath;



        [BeforeTestRun]
        [Obsolete]
        public static void InitializeReport()
        {


            var htmlReporter = new ExtentV3HtmlReporter(@"D:/CustomizedProjectReportmyn.html");
            htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Standard;

            extent = new ExtentReports();
            extent.AttachReporter(htmlReporter);

            htmlReporter.Config.DocumentTitle = "Automation Testing Report";
            htmlReporter.Config.ReportName = "Myntra  Testing";


            extent.AddSystemInfo("Tested By:", "Shada Najeeb");

            extent.AddSystemInfo("Environment", "QA");
            extent.AddSystemInfo("Machine", Environment.MachineName);
            extent.AddSystemInfo("OS", Environment.OSVersion.VersionString);

            //htmlReporter.Config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
            //log
            LoggingLevelSwitch levelSwitch = new LoggingLevelSwitch(LogEventLevel.Debug);
            //Serilog.Log.Logger = new LoggerConfiguration()
            //    .MinimumLevel.ControlledBy(levelSwitch)
            //    .WriteTo.File(@"D:\Logs",
            //    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} | {Level:u3} | {Message} {NewLine}",
            //    rollingInterval: RollingInterval.Day).CreateLogger();



        }

        [AfterTestRun]
        public static void TearDownReport()
        {
            extent.Flush();
        }

        [BeforeFeature]
        [Obsolete]
        public static void BeforeFeature()
        {

            //Create dynamic feature name
            Console.WriteLine("****BeforeFeature****");
            featureName = extent.CreateTest<Feature>(FeatureContext.Current.FeatureInfo.Title);
            //Serilog.Log.Information("Selecting feature file {0} to run", FeatureContext.Current.FeatureInfo.Title);
            Writelogger( FeatureContext.Current.FeatureInfo.Title);
        }
        public static void Writelogger(string message)
        {
            string logpath = System.Configuration.ConfigurationManager.AppSettings["logpath"];
            using (StreamWriter writer = new StreamWriter(logpath,true))
            {
                writer.WriteLine($"{DateTime.Now}:{message}");
            }
        }

        [AfterStep]
        [Obsolete]
        public void InsertReportingSteps(ScenarioContext ScenarioContext)
        {
            var StepInfo = ScenarioContext.StepContext.StepInfo;

            var stepType = ScenarioStepContext.Current.StepInfo.StepDefinitionType.ToString();






            PropertyInfo PInfo = typeof(ScenarioContext).GetProperty("ScenarioExecutionStatus", BindingFlags.Instance | BindingFlags.Public);
            MethodInfo Getter = PInfo.GetGetMethod(nonPublic: true);
            Object TestResult = Getter.Invoke(ScenarioContext.Current, null);


            if (ScenarioContext.Current.TestError == null)
            {
                if (stepType == "Given")
                {
                    scenario.CreateNode<Given>(stepType + " " + ScenarioStepContext.Current.StepInfo.Text);
                }

                else if (stepType == "When")
                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text);
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text);
                else if (stepType == "And")
                    scenario.CreateNode<And>(ScenarioStepContext.Current.StepInfo.Text);




            }
            else if (ScenarioContext.Current.TestError != null)
            {


                if (stepType == "Given")
                {
                    scenario.CreateNode<Given>(stepType + " " + ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message);
                }

                else if (stepType == "When")
                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message);
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message);//InnerException
                //Serilog.Log.Error("Test step failed | " + ScenarioContext.Current.TestError.Message);
                Writelogger(ScenarioContext.Current.TestError.Message);
                //test.Log(LogStatus.Fail, status + errorMessage);

                Screenshot Ss = ((ITakesScreenshot)driver).GetScreenshot();
                string screenshot = "image";


                Ss.SaveAsFile(@"D:\" + screenshot + ".png",
               ScreenshotImageFormat.Png);


                List<ScenarioExecutionStatus> FailTypes = new List<ScenarioExecutionStatus>();
                FailTypes.Add(

                ScenarioExecutionStatus.BindingError


                );
                FailTypes.Add(

                 ScenarioExecutionStatus.TestError

                );
                FailTypes.Add(

              ScenarioExecutionStatus.UndefinedStep


                );

            }

            //Pending Status
            if (TestResult.ToString() == "StepDefinitionPending")
            {
                if (stepType == "Given")
                {
                    scenario.CreateNode<Given>(stepType + " " + ScenarioStepContext.Current.StepInfo.Text).Skip("Step Definition Pending");
                }

                else if (stepType == "When")
                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text).Skip("Step Definition Pending");
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text).Skip("Step Definition Pending");
            }
            //Serilog.Log.Information("Selecting steps {0} to run", ScenarioStepContext.Current.StepInfo.Text);
            Writelogger( ScenarioStepContext.Current.StepInfo.Text);

        }

        [BeforeScenario]
        [Obsolete]
        void Initialize()
        {
            driver = new ChromeDriver();
            Common.Maximise();
            scenario = featureName.CreateNode<Scenario>(ScenarioContext.Current.ScenarioInfo.Title);
            //.AssignAuthor(ReadJson().Author);
            //Serilog.Log.Information("Selecting Scenario {0} to run ", ScenarioContext.Current.ScenarioInfo.Title);
            Writelogger(ScenarioContext.Current.ScenarioInfo.Title);
            Console.WriteLine("****In Before Scenario!****");
        }





        [AfterFeature]
        public static void AfterFeature1()
        {
            Console.WriteLine("**** After Feature!****");
        }




        [AfterScenario]
        public static void AfterScenario()
        {

            Thread.Sleep(2000);
            driver.Quit();
        }
        [AfterFeature]
        public static void AfterFeature()
        {

            //Thread.Sleep(2000);
            driver.Quit();
        }


        [BeforeStep]
        public static void BeforeStep1()
        {
            //Console.WriteLine("****In Before Step!****");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(12);
        }


       //private static  Style = IWebElement.GetAttribute(style);
       // //element.style {
       // //   };
}



}




