using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System;
using TechTalk.SpecFlow;

namespace Assessment5
{
    [Binding]
    public class HomepageStepDefinitions
    {
        IWebDriver driver = new ChromeDriver();
        [Given(@"The user is navigated to url")]
        public void GivenTheUserIsNavigatedToUrl()
        {
            Homepage homepage = new(driver);
            driver.Navigate().GoToUrl(" https://www.tatacliq.com/");
            driver.Manage().Window.Maximize();
            Thread.Sleep(2000);
            homepage.pop1.Click();
            Thread.Sleep(2000);
            //homepage.pop2.Click();

        }

        [When(@"verify the logo header")]
        public void WhenVerifyTheLogoHeader()
        {
            Homepage homepage = new(driver);

            Console.WriteLine("verified logo" + homepage.logo.Displayed);
        }

        [Then(@"verify the discount cuopon displayed")]
        public void ThenVerifyTheDiscountCuoponDisplayed()
        {
            Homepage homepage = new(driver);
            Thread.Sleep(2000);
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollTo(0, 500)");
            Console.WriteLine("verified coupon displayed" + homepage.coupon.Displayed);
        }

        [When(@"verify the options are dispalyed")]
        public void WhenVerifyTheOptionsAreDispalyed()
        {
            Homepage homepage = new(driver);
            Console.WriteLine("verified westside" + homepage.west.Displayed);
            Console.WriteLine("verified womens wear" + homepage.womenswear.Displayed);
            Console.WriteLine("verified beauty" + homepage.beauty.Displayed);
            Console.WriteLine("verified footwear" + homepage.footwear.Displayed);
            Console.WriteLine("verified menswear" + homepage.men.Displayed);
        }

        [Then(@"Mouse hover Categories to Kid'sFashion to BoysClothing and click on Shirts and verify the text Kids Boys Clothing Shirts is displayed")]
        public void ThenMouseHoverCategoriesToKidsFashionToBoysClothingAndClickOnShirtsAndVerifyTheTextKidsBoysClothingShirtsIsDisplayed()
        {
            Homepage homepage = new(driver);
            Shop shop = new(driver);
            Actions actions = new Actions(driver);
            actions.MoveToElement(homepage.category).Perform();
            //Thread.Sleep(2000);
            actions.MoveByOffset(0,100).Perform();
            actions.MoveToElement(homepage.kids).Perform();
            actions.MoveToElement(homepage.boy).Perform();
            Thread.Sleep(2000);
            homepage.boy.Click();
            //string actual = "Kids Boys Clothing Shirts";
            //string expected = shop.txt1.Text;
            //Thread.Sleep(2000);
            //Assert.AreEqual(expected, actual);
        }

        [When(@"Select the color black")]
        public void WhenSelectTheColorBlack()
        {
            Shop shop = new(driver);
            Thread.Sleep(3000);
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollTo(0, 500)");
            Thread.Sleep(1000);
            shop.filter.Click();
            Thread.Sleep(1000);
            shop.clr.Click();


        }

        [Then(@"click on the second item displayed")]
        public void ThenClickOnTheSecondItemDisplayed()
        {
            Shop shop = new(driver);
            Thread.Sleep(2000);
            shop.item2.Click();
        }

        [When(@"Print the original price without Discount and select one of the available sizes")]
        public void WhenPrintTheOriginalPriceWithoutDiscountAndSelectOneOfTheAvailableSizes()
        {
            Shop shop = new(driver);
            Thread.Sleep(2000);
            driver.SwitchTo().Window(driver.WindowHandles[1]);
            Thread.Sleep(3000);
            Console.Write("price is" + shop.price.Text);
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollTo(0, 200)");
            Thread.Sleep(3000);
            shop.size.Click();
            Thread.Sleep(3000);
            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollTo(0, 200)");
            //shop.addbag.Click();

        }

        [Then(@"Add to Bag and Go To Bag")]
        public void ThenAddToBagAndGoToBag()
        {
            Shop shop = new(driver);
            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            //js.ExecuteScript("window.scrollTo(0, 200)");
            shop.addbag.Click();
            Thread.Sleep(1000);
            shop.gotobag.Click();

        }

        [When(@"Give invalid Pin code")]
        public void WhenGiveInvalidPinCode()
        {
            Shop shop = new(driver);
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollTo(100, 0)");
            Thread.Sleep(3000);
            shop.pinchg.Click();
            Thread.Sleep(2000);
            //shop.pinenter.Click();
            shop.pinenter.SendKeys("00");
            Thread.Sleep(2000);
            shop.submit.Click();

        }

        [Then(@"verify the error message")]
        public void ThenVerifyTheErrorMessage()
        {
            Shop shop = new(driver);
            Console.WriteLine("error message displayed" + shop.emsg.Text);
            shop.close.Click();
        }

        [When(@"Click on the Check For Coupon")]
        public void WhenClickOnTheCheckForCoupon()
        {
            Shop shop = new(driver);
            Thread.Sleep(2000);
            shop.coupon2.Click();
            

        }

        [Then(@"if available and apply the first coupon")]
        public void ThenIfAvailableAndApplyTheFirstCoupon()
        {
            Shop shop = new(driver);
            Thread.Sleep(1000);
            shop.apply.Click();
           
        }

        [Then(@"Print the total displayed and verify the message")]
        public void ThenPrintTheTotalDisplayedAndVerifyTheMessage()
        {
            Shop shop = new(driver);
            Thread.Sleep(2000);
            Console.WriteLine("text is" + shop.text.Text);
            Console.WriteLine("total is" + shop.total.Text);

        }

        [When(@"Remove the item from the cart")]
        public void WhenRemoveTheItemFromTheCart()
        {
            Shop shop = new(driver);
            shop.remove.Click();
        }

        [Then(@"click on the continue shopping and verify the homepage is displayed")]
        public void ThenClickOnTheContinueShoppingAndVerifyTheHomepageIsDisplayed()
        {
            Shop shop = new(driver);
            Thread.Sleep(3000);
            shop.cotinue.Click();
        }
    }
}
