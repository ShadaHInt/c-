﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment5
{

    [TestClass]
    public class Homepagetest
    {
        [TestMethod]
        public void TestMethod1()
        {
            // IWebDriver driver = new EdgeDriver();
            IWebDriver driver = new ChromeDriver();

        }
    }
}
