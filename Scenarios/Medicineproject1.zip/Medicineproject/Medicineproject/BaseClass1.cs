﻿using OpenQA.Selenium;

namespace Medicineproject
{
    public class BaseClass1
    {
        public static IWebDriver driver;
    }
}
