﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using TechTalk.SpecFlow;

namespace Medicineproject
{
    [Binding]

    
    public sealed class Hooks1 : BaseClass1
    {

        
        private static ExtentTest? feature_Name;
        private static ExtentTest? scenario_name;
        private static ExtentReports? extent;
        
        

        [BeforeScenario]
        [Obsolete]
        void Initialize()
        {
            driver = new ChromeDriver();
            Common.Maximise();
            scenario_name = feature_Name.CreateNode<Scenario>("<i><b><font style='color:violet'>" + ScenarioContext.Current.ScenarioInfo.Title)
            .AssignAuthor("Shada Najeeb")
            .AssignCategory("<i>Scenario</i>");
            
            Serilog.Log.Information("Selecting Scenario {0} to run ", ScenarioContext.Current.ScenarioInfo.Title);


        }
        [BeforeTestRun]
        [Obsolete]
        public static void InitializeReport()
        {
            var htmlReporter = new ExtentV3HtmlReporter(@"D:/CustomizedProjectReport.html");
            htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Standard;

            htmlReporter.Config.DocumentTitle = "Automation Testing Report";
            htmlReporter.Config.ReportName = "<img src ='D:/online_medical_logo.png'/width='80'height='40'>Onlinemedicine Automation";

            extent = new ExtentReports();
            extent.AttachReporter(htmlReporter);
            extent.AddSystemInfo("<font style='color:blue'>" + "Tested Site", "<font style='color:orange'>Onlinemedicine Store</font>");
            extent.AddSystemInfo("<font style='color:blue'>" + "Tested By:", "<font style='color:orange'>Shada Najeeb</font>");

            extent.AddSystemInfo("<font style='color:blue'> " + "Environment", "<font style='color:orange'>QA</font>");
            extent.AddSystemInfo("<font style='color:blue'>" + "Machine", "<font style='color:orange'>"+ Environment.MachineName);
            extent.AddSystemInfo("<font style='color:blue'>" + "OS", "<font style='color:orange'>" + Environment.OSVersion.VersionString);
           
            LoggingLevelSwitch levelSwitch = new LoggingLevelSwitch(LogEventLevel.Debug);
            Serilog.Log.Logger = new LoggerConfiguration()
                .MinimumLevel.ControlledBy(levelSwitch)
                .WriteTo.File(@"D:\Logs.txt",
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} | {Level:u3} | {Message} {NewLine}|",
                rollingInterval: RollingInterval.Day).CreateLogger();

            
        }

        [AfterTestRun]
        public static void TearDownReport()
        {
            extent.Flush();
        }
        public static MediaEntityModelProvider CaptureScreenshot(String Name)
        {
            
            var screenshot = ((ITakesScreenshot)driver).GetScreenshot().AsBase64EncodedString;
            return MediaEntityBuilder.CreateScreenCaptureFromBase64String(screenshot,Name).Build();
            
        }

        
        [BeforeFeature]
        [Obsolete]
        public static void BeforeFeature()
        {
            
            Console.WriteLine("****BeforeFeature****");
            feature_Name = extent.CreateTest<Feature >(FeatureContext.Current.FeatureInfo.Title)
                .AssignCategory("<i>Feature</i>");
            Common.Style();
            Serilog.Log.Information("Selecting feature file {0} to run", FeatureContext.Current.FeatureInfo.Title);
            
        }

        [AfterStep]
        [Obsolete]
        public void InsertReportingSteps(ScenarioContext ScenarioContext)
        {
            var Step_Info = ScenarioContext.StepContext.StepInfo;

            var step_Type = ScenarioStepContext.Current.StepInfo.StepDefinitionType.ToString();



            var media = CaptureScreenshot(ScenarioContext.ScenarioInfo.Title.Trim());
            

            if (ScenarioContext.Current.TestError == null)
            {
                
                if (step_Type == "Given")
                {

                    scenario_name.CreateNode<Given>("<b><i><font style='color:slateblue'>" + ScenarioStepContext.Current.StepInfo.Text).Pass("", media)
                       .AssignCategory("<i>Step</i>");

                }

                else if (step_Type == "When")
                    scenario_name.CreateNode<When>("<b><i><font style ='color:slateblue'>" + ScenarioStepContext.Current.StepInfo.Text).Pass("", media)
                        .AssignCategory("<i>Step</i>");

                else if (step_Type == "Then")
                    scenario_name.CreateNode<Then>("<b><i><font style ='color:slateblue'>" + ScenarioStepContext.Current.StepInfo.Text).Pass("", media)
                        .AssignCategory("<i>Step</i>");

                Serilog.Log.Information("Selecting steps {0} to run", ScenarioStepContext.Current.StepInfo.Text);



            }
            else if (ScenarioContext.Current.TestError != null)
            {
                

                if (step_Type == "Given")
                {
                    scenario_name.CreateNode<Given>("<b><i><font style ='color:red'>" + ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message, media)
                        .AssignCategory("<i>Step</i>");


                }

                else if (step_Type == "When")
                    scenario_name.CreateNode<When>("<b><i> <font style ='color:red'>" + ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message, media)
                        .AssignCategory("<i>Step</i>");
                else if (step_Type == "Then")
                    scenario_name.CreateNode<Then>("<b><i><font style ='color:red'>" + ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message, media)
                        .AssignCategory("<i>Step</i>");
                Serilog.Log.Error("Test step failed | " + ScenarioContext.Current.TestError.Message);
            }

            
            

        }


        [AfterScenario]
        public static void AfterScenario()
        {

            
            driver.Quit();
        }
        [AfterFeature]
        public static void AfterFeature()
        {

            Thread.Sleep(2000);
            driver.Quit();
        }


        [BeforeStep]
        public static void BeforeStep1()
        {
            //Console.WriteLine("****In Before Step!****");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(7);
        }

    }
}