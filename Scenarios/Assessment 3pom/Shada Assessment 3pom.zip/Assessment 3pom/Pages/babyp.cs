﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_3pom
{
    public class Babyp
    {
        IWebDriver WebDriver;
        public Babyp(in IWebDriver driver)
        {

            WebDriver = driver;
            Assert.IsNotNull(WebDriver, "NO Driver instance provided");


        }
        public IWebElement price => WebDriver.FindElement(By.XPath("div[@class='ng-filters-v2 ng-scope']//child::div[1]"));
        public IWebElement allp => WebDriver.FindElement(By.XPath("//span[@class='sortbar-list']"));

        public IWebElement daily => WebDriver.FindElement(By.XPath("//span[text()='Daily Care']"));
        

        //div[@class='ng-filters-v2 ng-scope']//child::div[1]
    }
}
