using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;

namespace Assessment_3pom.stepdefnition
{
    [Binding]
    public class HomepageStepDefinitions
    {
        IWebDriver driver = new ChromeDriver();
        [Given(@"the url of the website")]
        public void GivenTheUrlOfTheWebsite()
        {
            Homepage homepage = new(driver);
            driver.Navigate().GoToUrl("https://www.hopscotch.in/");
            driver.Manage().Window.Maximize();
            string url = driver.Url;
            string urltotest = "https://www.hopscotch.in/";
            Assert.AreEqual(url, urltotest);
        }

        [When(@"Website is verified")]
        public void WhenWebsiteIsVerified()
        {
            Homepage homepage = new(driver);
            string url = driver.Url;
            string urltotest = "https://www.hopscotch.in/";
            Assert.AreEqual(url, urltotest);
        }

        [Then(@"all the elements are also verified if displayed")]
        public void ThenAllTheElementsAreAlsoVerifiedIfDisplayed()
        {
            Homepage homepage = new(driver);
            Thread.Sleep(TimeSpan.FromSeconds(2));
            string text = homepage.discover.Text;
            Console.WriteLine(text);
            string text1 = homepage.discover.Text;
            Console.WriteLine(text);
            string text2 = homepage.discover.Text;
            Console.WriteLine(text);

        }

        [When(@"user clicks all")]
        public void WhenUserClicksAll()
        {
            Homepage homepage = new(driver);
            homepage.allp.Click();
            Thread.Sleep(TimeSpan.FromSeconds(2));

        }

        [Then(@"user clicks daily care")]
        public void ThenUserClicksDailyCare()
        {
            Homepage homepage = new(driver);
            homepage.daily.Click();
        }
    }
}
