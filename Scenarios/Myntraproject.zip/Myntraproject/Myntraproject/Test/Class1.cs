﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;





namespace Myntraproject
    {
        public class Class1
        {
            public string valid { get; set; }
            
            public string invalid { get; set; }



        }
    }


