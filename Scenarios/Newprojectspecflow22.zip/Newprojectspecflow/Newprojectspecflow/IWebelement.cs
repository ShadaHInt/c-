﻿namespace Newprojectspecflow
{
    internal interface IWebelement
    {
    }
}