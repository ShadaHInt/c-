﻿

namespace InternalProjectTrial.JsonFile
{
    public class JsonClass
    {
        public string mobileone { get; set; }
        public string mobiletwo { get; set; }
        public string mobilethree { get; set; }    
        public string passwordone { get; set; }
        public string passwordtwo { get; set; }
        public string passwordthree { get; set; }
        public string search { get; set; }
        public string searchclothes { get; set; }
        public string name { get; set; }
        public string mobNo { get; set; }


    }
}
