using OpenQA.Selenium;

namespace InternalProjectTrial
{
    
    public class BaseClass
    {

        public static IWebDriver driver;
        
        
    }
}