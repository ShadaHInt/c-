﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Myntra31_01_23.Test
{
    public class Class1
    {
        public string valid { get; set; }

        



    }
}
